var clicks6 = 0;
function up6() {
    clicks6 += 1;
    document.getElementById("clicks6").innerHTML = clicks6;
};
function down6() {
    if(clicks6 >= 1)
    clicks6 -= 1;
    document.getElementById("clicks6").innerHTML = clicks6;
};

var clicks5 = 0;
    function up5() {
    clicks5 += 1;
    document.getElementById("clicks5").innerHTML = clicks5;
};
function down5() {
    if(clicks5 >= 1)
    clicks5 -= 1;
    document.getElementById("clicks5").innerHTML = clicks5;
};

var clicks4 = 0;
function up4() {
    clicks4 += 1;
    document.getElementById("clicks4").innerHTML = clicks4;
};
function down4() {
    if(clicks4 >= 1)
    clicks4 -= 1;
    document.getElementById("clicks4").innerHTML = clicks4;
};

var clicks3 = 0;
function up3() {
    clicks3 += 1;
    document.getElementById("clicks3").innerHTML = clicks3;
};
function down3() {
    if(clicks3 >= 1)
    clicks3 -= 1;
    document.getElementById("clicks3").innerHTML = clicks3;
};

var clicks2 = 0;
function up2() {
    clicks2 += 1;
    document.getElementById("clicks2").innerHTML = clicks2;
};
function down2() {
    if(clicks2 >= 1)
    clicks2 -= 1;
    document.getElementById("clicks2").innerHTML = clicks2;
};

var clicks = 0;
function up() {
   clicks += 1;
   document.getElementById("clicks").innerHTML = clicks;
};
function down() {
   if(clicks >= 1)
   clicks -= 1;
   document.getElementById("clicks").innerHTML = clicks;
};